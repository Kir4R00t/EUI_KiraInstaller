EUI mod version is 1.29i

UI_bc1 is a folder that contains the custom UI.
The XML file is just a "language pack" for the custom UI elements.
This mod acts as a "DLC" and therefore you can still gain achievements & play multiplayer while using it.

NOTE:
If your game crashes when you are making your first city on a fresh save you should remove "CityView" folder from the UI_bc1 folder.